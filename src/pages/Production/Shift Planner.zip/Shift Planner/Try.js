import React from 'react'

export default function Try() {
  return (
    <div><div style={{ marginTop: "-35px" }}>
    <div className='row'>
      <div className='col-md-4 col-sm-12 mt-4'>
        <div>
        </div>
      </div>

      <div className="col-md-8 col-sm-12">
        <div className="mt-3">
          <div className='row'>
            <div className="col-md-3">
              
            </div>

            {/* <button className="button-style mt-2 group-button mt-4"
              style={{ width: "150px" }} onClick={createWeekPlannEW}>
              Create Week Plan new
            </button> */}

            

            <div className="col-md-3">
              
            </div>

        {/* <button className="button-style mt-2 group-button mt-4"
           style={{ width: "140px"}}>
           Create Day Shift
        </button> */}
      </div>
  </div>
</div>

      <div className='col-md-4 col-sm-12'>
        
      </div>

      <div className="col-md-8 col-sm-12">
        <div className="mt-1">
          <div className='row'>
            <div className="col-md-3">
              
            </div>

       

            <div className="col-md-3">
              
            </div>

        

      </div>
  </div>
</div>
<div className='col-md-4 col-sm-12'>
        <div>
        </div>
      </div>

      <div className="col-md-8 col-sm-12">
        <div className="mt-1">
          <div className='row'>
            <div className="col-md-3">
            </div>

            

            <div className="col-md-3">
            </div>

            
      </div>
  </div>
</div>    
</div>
</div>
<hr  style={{
backgroundColor: 'black',
height:'3px'}}/></div>
  )
}
