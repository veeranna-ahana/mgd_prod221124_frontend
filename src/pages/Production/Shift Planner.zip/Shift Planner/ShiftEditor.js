import React from 'react'
import Header from './Header'
import NewCalender from './NewCalender'
import SecondTable from './SecondTable'

export default function ShiftEditor() {
  return (
    <div>
        {/* <Header/> */}
        
        <div>
        <NewCalender />
        </div>
       
    </div>
    
    
  )
}
